"""Current version of package GraPE."""
__version__ = "0.1.13"
