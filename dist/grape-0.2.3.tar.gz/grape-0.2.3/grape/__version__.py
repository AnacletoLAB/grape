"""Current version of package GRAPE."""
__version__ = "0.2.3"
