GraPE
===================================
|pip| |downloads|

Rust/Python for high performance Graph Processing and Embedding.

How do I install this package?
----------------------------------------------
As usual, just download it using pip:

.. code:: shell

    pip install grape