"""Current version of package GRAPE."""
__version__ = "0.1.17"
